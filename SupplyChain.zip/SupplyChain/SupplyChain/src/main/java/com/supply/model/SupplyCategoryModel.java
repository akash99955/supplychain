package com.supply.model;

public class SupplyCategoryModel {
    private int categoryId;
    private String name;
    private String type;
    private String description;

    public SupplyCategoryModel() {}

    public SupplyCategoryModel(int categoryId, String name, String type, String description) {
        this.categoryId = categoryId;
        this.name = name;
        this.type = type;
        this.description = description;
    }

    public int getCategoryId() {
        return categoryId;
    }
    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}
