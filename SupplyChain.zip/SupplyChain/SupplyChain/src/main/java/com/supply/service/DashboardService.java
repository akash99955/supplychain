package com.supply.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.supply.config.DbConfig;

public class DashboardService {

    public int getTotalProducts() {
        return getCount("SELECT COUNT(*) FROM products");
    }

    public int getTotalSuppliers() {
        return getCount("SELECT COUNT(*) FROM suppliers");
    }

    public int getPendingOrders() {
        return getCount("SELECT COUNT(*) FROM supply_orders WHERE status = 'pending'");
    }

    public int getDeliveredOrders() {
        return getCount("SELECT COUNT(*) FROM supply_orders WHERE status = 'delivered'");
    }

    private int getCount(String query) {
        int count = 0;
        Connection conn = null;
        try {
            conn = DbConfig.getDbConnection();
            if (conn == null) {
                System.err.println("Failed to establish database connection.");
                return count;
            }
            try (PreparedStatement stmt = conn.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error executing query: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.err.println("Error closing connection: " + e.getMessage());
                }
            }
        }
        return count;
    }
}
