package com.supply.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class SupplyModel {

    // --- ADD THIS FIELD ---
    private int supplyId;
    // --- END ADD ---

    private String sku;
    private String name;
    private String category;
    private String status;
    private int quantity;
    private LocalDate receivedDate;
    private String imagePath;
    private String description;
    private BigDecimal unitPrice;

    // Constructors
    public SupplyModel() {
    }

    // --- ADD GETTER AND SETTER for supplyId ---
    public int getSupplyId() {
        return supplyId;
    }

    public void setSupplyId(int supplyId) {
        this.supplyId = supplyId;
    }
    // --- END ADD ---

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public LocalDate getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(LocalDate receivedDate) {
        this.receivedDate = receivedDate;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    // Optional: toString(), equals(), and hashCode() if needed
}
