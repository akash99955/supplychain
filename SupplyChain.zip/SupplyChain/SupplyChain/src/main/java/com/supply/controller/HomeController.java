package com.supply.controller;

import com.supply.model.SupplyModel;
import com.supply.service.SupplyService;
import com.supply.util.CookieUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet(asyncSupported = true, urlPatterns = { "/home" }) // Specific mapping
public class HomeController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final SupplyService supplyService;

    public HomeController() {
        this.supplyService = new SupplyService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("HomeController: doGet called for path /home");

        // --- Role Check ---
        String role = CookieUtil.getCookie(request, "role") != null ? CookieUtil.getCookie(request, "role").getValue() : null;
        if ("admin".equals(role)) {
            System.out.println("HomeController: Admin user detected, redirecting to /admin");
            response.sendRedirect(request.getContextPath() + "/admin");
            return;
        }
        // --- End Role Check ---

        // --- Check DB Connection ---
        if (supplyService.isConnectionError()) {
            System.err.println("HomeController: Database connection error. Setting error attribute.");
            request.setAttribute("errorMessage", supplyService.getLastErrorMessage());
            request.getRequestDispatcher("/WEB-INF/pages/home.jsp").forward(request, response);
            return;
        }
        // --- End DB Connection Check ---

        // --- Decide between Search and Categorized View ---
        String searchQuery = request.getParameter("searchQuery");

        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            // --- Handle Search ---
            System.out.println("HomeController: Performing search for query: '" + searchQuery + "'");
            List<SupplyModel> searchResults = supplyService.searchAvailableSupplies(searchQuery);
            request.setAttribute("searchResults", searchResults);
            request.setAttribute("searchQuery", searchQuery);
            System.out.println("HomeController: Found " + searchResults.size() + " search results.");
        } else {
            // --- Handle Default Categorized View ---
            System.out.println("HomeController: Fetching categorized available supplies.");
            Map<String, List<SupplyModel>> categorizedSupplies = supplyService.getCategorizedAvailableSupplies();
            request.setAttribute("categorizedSupplies", categorizedSupplies);
            System.out.println("HomeController: Found " + categorizedSupplies.size() + " categories.");
        }
        // --- End Decision Logic ---

        // --- Forward to JSP ---
        System.out.println("HomeController: Forwarding to home.jsp");
        request.getRequestDispatcher("/WEB-INF/pages/home.jsp").forward(request, response);
    }
}
