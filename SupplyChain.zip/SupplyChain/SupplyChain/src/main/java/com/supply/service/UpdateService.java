package com.supply.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.supply.config.DbConfig;
import com.supply.model.SupplyModel;

/**
 * Service class for updating supply information in the database.
 * 
 * This class provides methods to update supply details and fetch category IDs
 * from the database. It manages database connections and handles SQL
 * exceptions.
 */
public class UpdateService {
	private Connection dbConn;
	private boolean isConnectionError = false;

	/**
	 * Constructor initializes the database connection. Sets the connection error
	 * flag if the connection fails.
	 */
	public UpdateService() {
		try {
			dbConn = DbConfig.getDbConnection();
		} catch (SQLException | ClassNotFoundException ex) {
			// Log and handle exceptions related to database connection
			ex.printStackTrace();
			isConnectionError = true;
		}
	}

	/**
	 * Updates supply information in the database.
	 * 
	 * @param supply The SupplyModel object containing the updated supply data.
	 * @return Boolean indicating the success of the update operation. Returns null
	 *         if there is a connection error or an exception occurs.
	 */
	public Boolean updateSupplyInfo(SupplyModel supply) {
		if (isConnectionError) {
			return null;
		}

		int categoryId = getCategoryId(supply.getCategory());
		if (categoryId == 0) {
			System.out.println("Invalid category: " + supply.getCategory());
			return false;
		}

		String updateSQL = "UPDATE supply SET name = ?, category_id = ?, quantity = ?, supplier = ?, price = ?, date_received = ?, image_url = ? "
				+ "WHERE supply_id = ?";

		try (PreparedStatement preparedStatement = dbConn.prepareStatement(updateSQL)) {
			preparedStatement.setString(1, supply.getName());
			preparedStatement.setInt(2, categoryId);
			preparedStatement.setString(3, supply.getQuantity());
			preparedStatement.setString(4, supply.getSupplier());
			preparedStatement.setDouble(5, supply.getPrice());
			preparedStatement.setDate(6, java.sql.Date.valueOf(supply.getDateReceived()));
			preparedStatement.setString(7, supply.getImageUrl());
			preparedStatement.setInt(8, supply.getId());

			int rowsAffected = preparedStatement.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Retrieves the supply category ID for a given category name.
	 * 
	 * @param categoryName The name of the supply category.
	 * @return The ID of the category. Returns 0 if the category is not found or an
	 *         exception occurs.
	 */
	private int getCategoryId(String categoryName) {
		String selectSQL = "SELECT category_id FROM supply_category WHERE name = ?";

		try (PreparedStatement preparedStatement = dbConn.prepareStatement(selectSQL)) {
			preparedStatement.setString(1, categoryName);
			ResultSet result = preparedStatement.executeQuery();

			if (result.next()) {
				return result.getInt("category_id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return 0;
	}
}

