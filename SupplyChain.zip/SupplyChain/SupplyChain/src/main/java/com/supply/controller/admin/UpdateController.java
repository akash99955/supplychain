package com.supply.controller.admin;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.supply.model.SupplyModel;
import com.supply.service.UpdateService;
import com.supply.util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation for handling supply update operations.
 * 
 * This servlet processes HTTP requests for updating supply item information.
 * It interacts with the UpdateService to perform database operations and 
 * forwards requests to the appropriate JSP page for user interaction.
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/supplyUpdate" })
public class UpdateController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Service for updating supply information
    private UpdateService updateService;

    /**
     * Default constructor initializes the UpdateService instance.
     */
    public UpdateController() {
        this.updateService = new UpdateService();
    }

    /**
     * Handles HTTP GET requests by retrieving supply information from the session 
     * and forwarding the request to the update JSP page.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        // Retrieve and set supply information from the session if available
        if (req.getSession().getAttribute("supply") != null) {
            SupplyModel supply = (SupplyModel) SessionUtil.getAttribute(req, "supply");
            SessionUtil.removeAttribute(req, "supply");
            req.setAttribute("supply", supply);
        }

        // Forward to the supply update JSP page
        req.getRequestDispatcher("/WEB-INF/pages/admin/supply-update.jsp").forward(req, resp);
    }

    /**
     * Handles HTTP POST requests for updating supply information.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        // Retrieve supply data from request parameters
        int supplyId = Integer.parseInt(req.getParameter("supplyId"));
        String name = req.getParameter("name");
        String category = req.getParameter("category");
        String quantity = req.getParameter("quantity");
        String supplier = req.getParameter("supplier");
        double price = Double.parseDouble(req.getParameter("price"));
        String imageUrl = req.getParameter("imageUrl");

        // Parse dateReceived to LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dateReceived = LocalDate.parse(req.getParameter("dateReceived"), formatter);

        // Create a SupplyModel object with updated values
        SupplyModel supply = new SupplyModel(name, category, quantity, supplier, price, dateReceived, imageUrl);
        supply.setId(supplyId); // Set ID for update

        // Attempt to update supply info in database
        Boolean result = updateService.updateSupplyInfo(supply);
        if (result != null && result) {
            resp.sendRedirect(req.getContextPath() + "/manageSupplies"); // Redirect on success
        } else {
            req.getSession().setAttribute("supply", supply);
            handleUpdateFailure(req, resp, result); // Handle failure
        }
    }

    /**
     * Handles update failures by setting an error message and forwarding to the update form.
     */
    private void handleUpdateFailure(HttpServletRequest req, HttpServletResponse resp, Boolean updateStatus)
            throws ServletException, IOException {
        String errorMessage;
        if (updateStatus == null) {
            errorMessage = "Our server is under maintenance. Please try again later!";
        } else {
            errorMessage = "Supply update failed. Please try again!";
        }
        req.setAttribute("error", errorMessage);
        req.getRequestDispatcher("/WEB-INF/pages/admin/supply-update.jsp").forward(req, resp);
    }
}
