package com.supply.service;

import com.supply.model.SupplyModel;
import com.supply.config.DbConfig;

import java.sql.*;
import java.sql.Date;
import java.util.*;

public class SupplyService {
    private final Connection dbConn;
    private String lastErrorMessage;
    private boolean isConnectionError;
    
    // Default categories that will always appear
    private static final List<String> DEFAULT_CATEGORIES = Arrays.asList(
        "Office Supplies",
        "Electronics",
        "Furniture"
    );

    public SupplyService() {
        Connection tempConn = null;
        try {
            tempConn = DbConfig.getDbConnection();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            isConnectionError = true;
            lastErrorMessage = "Failed to establish database connection: " + e.getMessage();
        }
        this.dbConn = tempConn;
    }

    public boolean addSupply(SupplyModel supply) {
        if (isConnectionError || dbConn == null) {
            lastErrorMessage = "Cannot add supply due to database connection error";
            return false;
        }

        String sql = "INSERT INTO supplies (sku, name, category, status, quantity, received_date, image_path, description, unit_price) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = dbConn.prepareStatement(sql)) {
            pstmt.setString(1, supply.getSku());
            pstmt.setString(2, supply.getName());
            pstmt.setString(3, supply.getCategory());
            pstmt.setString(4, supply.getStatus());
            pstmt.setInt(5, supply.getQuantity());
            pstmt.setObject(6, supply.getReceivedDate() != null ? Date.valueOf(supply.getReceivedDate()) : null);
            pstmt.setString(7, supply.getImagePath());
            pstmt.setString(8, supply.getDescription());
            pstmt.setBigDecimal(9, supply.getUnitPrice());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            lastErrorMessage = "Error adding supply: " + e.getMessage();
            e.printStackTrace();
            return false;
        }
    }

    public Map<String, List<SupplyModel>> getCategorizedAvailableSupplies() {
        Map<String, List<SupplyModel>> categorizedSupplies = new LinkedHashMap<>();

        // Initialize with default categories first
        DEFAULT_CATEGORIES.forEach(category -> 
            categorizedSupplies.put(category, new ArrayList<>())
        );

        if (isConnectionError || dbConn == null) {
            lastErrorMessage = "Cannot fetch supplies due to database connection error";
            System.err.println("SupplyService: " + lastErrorMessage);
            return categorizedSupplies; // Returns map with empty lists for default categories
        }

        String sql = "SELECT id, sku, name, category, status, quantity, received_date, image_path, description, unit_price " +
                     "FROM Supplies WHERE status = ? ORDER BY category, name";

        try (PreparedStatement pstmt = dbConn.prepareStatement(sql)) {
            pstmt.setString(1, "Available");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                SupplyModel supply = mapResultSetToSupplyModel(rs);
                categorizedSupplies.computeIfAbsent(supply.getCategory(), k -> new ArrayList<>()).add(supply);
            }
        } catch (SQLException e) {
            lastErrorMessage = "Error fetching categorized supplies: " + e.getMessage();
            e.printStackTrace();
        }

        return categorizedSupplies;
    }

    public List<SupplyModel> searchAvailableSupplies(String searchQuery) {
        List<SupplyModel> supplies = new ArrayList<>();

        if (isConnectionError || dbConn == null) {
            lastErrorMessage = "Cannot search supplies due to database connection error";
            System.err.println("SupplyService: " + lastErrorMessage);
            return supplies;
        }

        if (searchQuery == null || searchQuery.trim().isEmpty()) {
            return supplies;
        }

        String queryParam = "%" + searchQuery.toLowerCase() + "%";
        String sql = "SELECT id, sku, name, category, status, quantity, received_date, image_path, description, unit_price " +
                     "FROM Supplies " +
                     "WHERE status = ? AND (" +
                     "LOWER(name) LIKE ? OR " +
                     "LOWER(category) LIKE ? OR " +
                     "LOWER(sku) LIKE ? OR " +
                     "LOWER(description) LIKE ? ) " +
                     "ORDER BY category, name";

        try (PreparedStatement pstmt = dbConn.prepareStatement(sql)) {
            pstmt.setString(1, "Available");
            for (int i = 2; i <= 5; i++) {
                pstmt.setString(i, queryParam);
            }

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                supplies.add(mapResultSetToSupplyModel(rs));
            }
        } catch (SQLException e) {
            lastErrorMessage = "Error searching supplies: " + e.getMessage();
            e.printStackTrace();
        }

        return supplies;
    }

    private SupplyModel mapResultSetToSupplyModel(ResultSet rs) throws SQLException {
        SupplyModel supply = new SupplyModel();
        supply.setSupplyId(rs.getInt("id"));
        supply.setSku(rs.getString("sku"));
        supply.setName(rs.getString("name"));
        supply.setCategory(rs.getString("category"));
        supply.setStatus(rs.getString("status"));
        supply.setQuantity(rs.getInt("quantity"));
        Date receivedDateSql = rs.getDate("received_date");
        supply.setReceivedDate(receivedDateSql != null ? receivedDateSql.toLocalDate() : null);
        supply.setImagePath(rs.getString("image_path"));
        supply.setDescription(rs.getString("description"));
        supply.setUnitPrice(rs.getBigDecimal("unit_price"));
        return supply;
    }

    public String getLastErrorMessage() {
        return lastErrorMessage;
    }

    public boolean isConnectionError() {
        return isConnectionError;
    }
}