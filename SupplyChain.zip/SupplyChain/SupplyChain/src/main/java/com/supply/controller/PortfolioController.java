package com.supply.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.supply.config.DbConfig;
import com.supply.model.UserModel;
import com.supply.util.PasswordUtil;
import com.supply.util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.logging.Logger;

/**
 * PortfolioController handles requests to the user profile page
 * in the Supply Chain Management System.
 * Allows viewing and updating user details.
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/portfolio" })
public class PortfolioController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ValidationUtil validationUtil;
    private static final Logger LOGGER = Logger.getLogger(PortfolioController.class.getName());

    @Override
    public void init() throws ServletException {
        this.validationUtil = new ValidationUtil();
    }

    /**
     * Handles GET requests to display user profile.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userIdStr = (String) req.getSession().getAttribute("userId");
        if (userIdStr == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        int userId;
        try {
            userId = Integer.parseInt(userIdStr);
        } catch (NumberFormatException e) {
            LOGGER.severe("Failed to parse userId from session: " + e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        UserModel user = getUserDetails(userId);
        if (user == null) {
            req.setAttribute("error", "Unable to fetch user details. Please try again later.");
            req.getRequestDispatcher("WEB-INF/pages/login.jsp").forward(req, resp);
            return;
        }

        req.setAttribute("user", user);
        req.getRequestDispatcher("WEB-INF/pages/portfolio.jsp").forward(req, resp);
    }

    /**
     * Handles POST requests to update profile details.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userIdStr = (String) req.getSession().getAttribute("userId");
        if (userIdStr == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        int userId;
        try {
            userId = Integer.parseInt(userIdStr);
        } catch (NumberFormatException e) {
            LOGGER.severe("Failed to parse userId from session: " + e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String fullName = req.getParameter("full_name");
        String email = req.getParameter("email");
        String phoneNumber = req.getParameter("phone_number");
        String password = req.getParameter("password");
        String username = (String) req.getSession().getAttribute("username");

        // Validate input
        if (fullName == null || fullName.trim().isEmpty()) {
            req.setAttribute("error", "Full name cannot be empty.");
            reloadPortfolioPage(userId, req, resp);
            return;
        }

        if (email != null && !email.isEmpty() && !validationUtil.validateEmail(email)) {
            req.setAttribute("error", "Invalid email format!");
            reloadPortfolioPage(userId, req, resp);
            return;
        }

        if (phoneNumber != null && !phoneNumber.isEmpty() && !validationUtil.validatePhoneNumber(phoneNumber)) {
            req.setAttribute("error", "Invalid phone number! Use format +1234567890.");
            reloadPortfolioPage(userId, req, resp);
            return;
        }

        if (password != null && !password.isEmpty() && !validationUtil.isValidPassword(password)) {
            req.setAttribute("error", "Password must have 8+ characters, 1 uppercase, 1 number, and 1 symbol.");
            reloadPortfolioPage(userId, req, resp);
            return;
        }

        if (email != null && !email.isEmpty() && isEmailTaken(email, userId)) {
            req.setAttribute("error", "This email is already used by another account.");
            reloadPortfolioPage(userId, req, resp);
            return;
        }

        boolean updated = updateUser(userId, fullName, email, phoneNumber, password, username);
        if (updated) {
            req.setAttribute("success", "Profile updated successfully!");
        } else {
            req.setAttribute("error", "Update failed. Please try again.");
        }

        reloadPortfolioPage(userId, req, resp);
    }

    private UserModel getUserDetails(int userId) {
        try (Connection conn = DbConfig.getDbConnection()) {
            String query = "SELECT username, full_name, email, phone_number FROM user WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, userId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    UserModel user = new UserModel();
                    user.setUserId(userId);
                    user.setUsername(rs.getString("username"));
                    user.setFullName(rs.getString("full_name"));
                    user.setEmail(rs.getString("email"));
                    user.setPhoneNumber(rs.getString("phone_number"));
                    return user;
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            LOGGER.severe("Error fetching user details: " + e.getMessage());
        }
        return null;
    }

    private boolean updateUser(int userId, String fullName, String email, String phoneNumber, String password, String username) {
        try (Connection conn = DbConfig.getDbConnection()) {
            String encryptedPassword = null;
            if (password != null && !password.isEmpty()) {
                encryptedPassword = PasswordUtil.encrypt(username, password);
                if (encryptedPassword == null) {
                    return false;
                }
            }

            StringBuilder query = new StringBuilder("UPDATE user SET full_name = ?, email = ?, phone_number = ?");
            if (encryptedPassword != null) {
                query.append(", password = ?");
            }
            query.append(" WHERE id = ?");

            try (PreparedStatement stmt = conn.prepareStatement(query.toString())) {
                stmt.setString(1, fullName);
                stmt.setString(2, email != null && !email.isEmpty() ? email : null);
                stmt.setString(3, phoneNumber != null && !phoneNumber.isEmpty() ? phoneNumber : null);
                int paramIndex = 4;
                if (encryptedPassword != null) {
                    stmt.setString(paramIndex++, encryptedPassword);
                }
                stmt.setInt(paramIndex, userId);

                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException | ClassNotFoundException e) {
            LOGGER.severe("Error updating user: " + e.getMessage());
            return false;
        }
    }

    private boolean isEmailTaken(String email, int currentUserId) {
        try (Connection conn = DbConfig.getDbConnection()) {
            String query = "SELECT id FROM user WHERE email = ? AND id != ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, email);
                stmt.setInt(2, currentUserId);
                ResultSet rs = stmt.executeQuery();
                return rs.next();
            }
        } catch (SQLException | ClassNotFoundException e) {
            LOGGER.severe("Error checking if email is taken: " + e.getMessage());
            return false;
        }
    }

    private void reloadPortfolioPage(int userId, HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        UserModel user = getUserDetails(userId);
        req.setAttribute("user", user);
        req.getRequestDispatcher("WEB-INF/pages/portfolio.jsp").forward(req, resp);
    }
}
