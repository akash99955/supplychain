package com.supply.service;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import com.supply.model.ActivityModel;
import com.supply.dao.InventoryDAO;
import com.supply.dao.OrderDAO;
import com.supply.dao.ShipmentDAO;
import com.supply.dao.ActivityDAO;

/**
 * Service class for retrieving dashboard metrics and KPIs for the supply chain dashboard
 */
public class SupplyChainDashboardService {
    
    private final InventoryDAO inventoryDAO;
    private final OrderDAO orderDAO;
    private final ShipmentDAO shipmentDAO;
    private final ActivityDAO activityDAO;
    
    /**
     * Constructor initializes all required DAOs
     */
    public SupplyChainDashboardService() {
        this.inventoryDAO = new InventoryDAO();
        this.orderDAO = new OrderDAO();
        this.shipmentDAO = new ShipmentDAO();
        this.activityDAO = new ActivityDAO();
    }
    
    /**
     * Get total number of inventory items
     */
    public int getTotalInventoryItems() {
        try {
            return inventoryDAO.getTotalItems();
        } catch (Exception e) {
            System.err.println("Error fetching total inventory items: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * Get items with stock below minimum threshold
     */
    public int getLowStockItems() {
        try {
            return inventoryDAO.getLowStockItemsCount();
        } catch (Exception e) {
            System.err.println("Error fetching low stock items: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * Get count of pending orders
     */
    public int getPendingOrders() {
        try {
            return orderDAO.getCountByStatus("Pending");
        } catch (Exception e) {
            System.err.println("Error fetching pending orders: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * Get count of active shipments
     */
    public int getActiveShipments() {
        try {
            return shipmentDAO.getActiveShipmentsCount();
        } catch (Exception e) {
            System.err.println("Error fetching active shipments: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * Calculate on-time delivery rate as a percentage
     */
    public double getOnTimeDeliveryRate() {
        try {
            // Get completed deliveries in the last 30 days
            int totalDeliveries = shipmentDAO.getCompletedDeliveriesCount(30);
            if (totalDeliveries == 0) {
                return 100.0; // No deliveries to measure
            }
            
            int onTimeDeliveries = shipmentDAO.getOnTimeDeliveriesCount(30);
            return Math.round((double) onTimeDeliveries / totalDeliveries * 100);
        } catch (Exception e) {
            System.err.println("Error calculating on-time delivery rate: " + e.getMessage());
            e.printStackTrace();
            return 0.0;
        }
    }
    
    /**
     * Calculate inventory turnover ratio
     * (Cost of goods sold / Average inventory value)
     */
    public double getInventoryTurnover() {
        try {
            double costOfGoodsSold = orderDAO.getCostOfGoodsSoldLastQuarter();
            double averageInventoryValue = inventoryDAO.getAverageInventoryValue();
            
            if (averageInventoryValue == 0) {
                return 0.0;
            }
            
            // Round to 2 decimal places
            return Math.round((costOfGoodsSold / averageInventoryValue) * 100.0) / 100.0;
        } catch (Exception e) {
            System.err.println("Error calculating inventory turnover: " + e.getMessage());
            e.printStackTrace();
            return 0.0;
        }
    }
    
    /**
     * Calculate inventory turnover trend compared to previous period
     * Returns percentage change
     */
    public double getInventoryTurnoverTrend() {
        try {
            double currentTurnover = orderDAO.getCostOfGoodsSoldLastQuarter() / 
                                    inventoryDAO.getAverageInventoryValue();
            
            double previousTurnover = orderDAO.getCostOfGoodsSoldPreviousQuarter() / 
                                     inventoryDAO.getAverageInventoryValuePreviousQuarter();
            
            if (previousTurnover == 0) {
                return 0.0;
            }
            
            double percentChange = ((currentTurnover - previousTurnover) / previousTurnover) * 100;
            
            // Round to 1 decimal place
            return Math.round(percentChange * 10.0) / 10.0;
        } catch (Exception e) {
            System.err.println("Error calculating inventory turnover trend: " + e.getMessage());
            e.printStackTrace();
            return 0.0;
        }
    }
    
    /**
     * Calculate order fulfillment rate
     */
    public double getOrderFulfillmentRate() {
        try {
            int totalOrdersLastMonth = orderDAO.getTotalOrdersLastMonth();
            if (totalOrdersLastMonth == 0) {
                return 100.0; // No orders to measure
            }
            
            int fulfilledOrdersLastMonth = orderDAO.getFulfilledOrdersLastMonth();
            return Math.round((double) fulfilledOrdersLastMonth / totalOrdersLastMonth * 100);
        } catch (Exception e) {
            System.err.println("Error calculating order fulfillment rate: " + e.getMessage());
            e.printStackTrace();
            return 0.0;
        }
    }
    
    /**
     * Get recent activities for the dashboard
     */
    public List<ActivityModel> getRecentActivities(int limit) {
        try {
            return activityDAO.getRecentActivities(limit);
        } catch (Exception e) {
            System.err.println("Error fetching recent activities: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    // Additional helper methods
    
    /**
     * Get predicted days to stockout for a specific item
     */
    public int getDaysToStockout(int itemId) {
        try {
            return inventoryDAO.calculateDaysToStockout(itemId);
        } catch (Exception e) {
            System.err.println("Error calculating days to stockout: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }
    
    /**
     * Calculate average lead time from order to delivery in days
     */
    public double getAverageLeadTime() {
        try {
            return orderDAO.calculateAverageLeadTimeInDays();
        } catch (Exception e) {
            System.err.println("Error calculating average lead time: " + e.getMessage());
            e.printStackTrace();
            return 0.0;
        }
    }
}
