/*package com.supply.controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.supply.service.DashboardService;

/**
 * Servlet implementation for handling supply dashboard-related HTTP requests.
 * 
 * This servlet manages interactions with the DashboardService to fetch supply
 * information, handle summary data, and forward to the JSP for display.
 */
/*
@WebServlet(asyncSupported = true, urlPatterns = { "/supplyDashboard" })
public class DashboardController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Instance of DashboardService for handling business logic
	private DashboardService dashboardService;

	/**
	 * Default constructor initializes the DashboardService instance.
	 */
/*
	public DashboardController() {
		this.dashboardService = new DashboardService();
	}

	/**
	 * Handles HTTP GET requests by retrieving supply information and forwarding
	 * the request to the supply dashboard JSP page.
	 * 
	 * @param request  The HttpServletRequest object containing the request data.
	 * @param response The HttpServletResponse object used to return the response.
	 * @throws ServletException If an error occurs during request processing.
	 * @throws IOException      If an input or output error occurs.
	 */
	/*
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Retrieve all supply information from the DashboardService
		request.setAttribute("supplyList", dashboardService.getAllSupplies());

		// Summary statistics for supplies (example methods – ensure you implement these)
		request.setAttribute("totalSupplies", dashboardService.getTotalSupplies());
		request.setAttribute("categories", dashboardService.getAllCategories());
		request.setAttribute("recentSupplies", dashboardService.getRecentSupplies());

		// Forward the request to the supplies JSP for rendering
		request.getRequestDispatcher("/WEB-INF/pages/admin/supplies.jsp").forward(request, response);
	}
}*/

