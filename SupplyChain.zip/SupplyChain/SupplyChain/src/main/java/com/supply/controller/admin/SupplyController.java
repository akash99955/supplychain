package com.supply.controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

import com.supply.model.SupplyCategoryModel;
import com.supply.service.DashboardService;
import com.supply.util.ValidationUtil;

/**
 * Servlet implementation class SupplyController
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/modifySupplies" })
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
		maxFileSize = 1024 * 1024 * 10, // 10MB
		maxRequestSize = 1024 * 1024 * 50) // 50MB
public class SupplyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Instance of DashboardService for handling business logic
	private DashboardService dashboardService;

	/**
	 * Default constructor initializes the DashboardService instance.
	 */
	public SupplyController() {
		this.dashboardService = new DashboardService();
	}

	/**
	 * Handles HTTP GET requests to retrieve all supply information and forward to the supplies JSP.
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("supplyList", dashboardService.getAllSupplies());
		request.getRequestDispatcher("/WEB-INF/pages/admin/supply.jsp").forward(request, response);
	}

	/**
	 * Handles HTTP POST requests for update, delete, and updateForm actions for supplies.
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		int supplyId = Integer.parseInt(request.getParameter("supplyId"));

		switch (action) {
		case "updateForm":
			try {
				handleUpdateForm(request, response, supplyId);
			} catch (ClassNotFoundException | ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "update":
			handleUpdate(request, response, supplyId);
			break;
		case "delete":
			handleDelete(request, response, supplyId);
			break;
		default:
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown action: " + action);
		}
	}

	/**
	 * Handles the updateForm action by retrieving a specific supply and redirecting to the update page.
	 * @throws ClassNotFoundException 
	 */
	private void handleUpdateForm(HttpServletRequest request, HttpServletResponse response, int supplyId)
			throws ServletException, IOException, ClassNotFoundException {
		SupplyCategoryModel supply = dashboardService.getSpecificSupplyCategoryInfo(supplyId);

		if (supply != null) {
			request.getSession().setAttribute("supply", supply);
			response.sendRedirect(request.getContextPath() + "/supplyUpdate");
		} else {
			response.sendError(HttpServletResponse.SC_NOT_FOUND, "Supply not found with ID: " + supplyId);
		}
	}

	/**
	 * Handles updating a supply entry with new form data.
	 */
	private void handleUpdate(HttpServletRequest request, HttpServletResponse response, int supplyId)
			throws ServletException, IOException {
		String validationMessage = validateUpdateForm(request);
		if (validationMessage != null) {
			request.setAttribute("error", validationMessage);
			doGet(request, response); // reload with error
			return;
		}

		String name = request.getParameter("name");
		String type = request.getParameter("type");
		String description = request.getParameter("description");

		SupplyCategoryModel supply = new SupplyCategoryModel();
		supply.setCategoryId(supplyId);
		supply.setName(name);
		supply.setType(type);
		supply.setDescription(description);

		boolean success = dashboardService.updateCategory(supply);

		if (success) {
			request.setAttribute("success", "Supply updated successfully.");
		} else {
			request.setAttribute("error", "Failed to update supply.");
		}

		doGet(request, response);
	}

	/**
	 * Validates form fields for the update operation.
	 */
	private String validateUpdateForm(HttpServletRequest request) {
		String name = request.getParameter("name");
		String type = request.getParameter("type");
		String description = request.getParameter("description");

		if (ValidationUtil.isNullOrEmpty(name))
			return "Name is required.";
		if (ValidationUtil.isNullOrEmpty(type))
			return "Type is required.";
		if (ValidationUtil.isNullOrEmpty(description))
			return "Description is required.";

		if (!ValidationUtil.isAlphanumericStartingWithLetter(name))
			return "Name must start with a letter and contain only letters and numbers.";
		if (type.length() > 50)
			return "Type is too long.";
		if (description.length() > 200)
			return "Description must be under 200 characters.";

		return null;
	}

	/**
	 * Handles deleting a supply entry by ID.
	 */
	private void handleDelete(HttpServletRequest request, HttpServletResponse response, int supplyId)
			throws ServletException, IOException {
		boolean success = dashboardService.deleteSupply(supplyId);

		if (success) {
			System.out.println("Supply deleted successfully.");
		} else {
			System.out.println("Failed to delete supply.");
		}

		doGet(request, response);
	}
}
